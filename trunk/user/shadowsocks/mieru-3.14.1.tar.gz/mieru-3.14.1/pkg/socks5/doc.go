// Package socks5 is imported from https://github.com/armon/go-socks5 and
// https://github.com/h12w/socks
package socks5
