// Package app contains feature implementations of V2Ray. The features may be enabled during runtime.
package app
