// Package log is is imported from https://github.com/sirupsen/logrus
package log
