package observatory

import (
	_ "github.com/v2fly/v2ray-core/v5/common/protoext"
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

type ObservationResult struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	Status        []*OutboundStatus      `protobuf:"bytes,1,rep,name=status,proto3" json:"status,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *ObservationResult) Reset() {
	*x = ObservationResult{}
	mi := &file_app_observatory_config_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *ObservationResult) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*ObservationResult) ProtoMessage() {}

func (x *ObservationResult) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_config_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use ObservationResult.ProtoReflect.Descriptor instead.
func (*ObservationResult) Descriptor() ([]byte, []int) {
	return file_app_observatory_config_proto_rawDescGZIP(), []int{0}
}

func (x *ObservationResult) GetStatus() []*OutboundStatus {
	if x != nil {
		return x.Status
	}
	return nil
}

type HealthPingMeasurementResult struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	All           int64                  `protobuf:"varint,1,opt,name=all,proto3" json:"all,omitempty"`
	Fail          int64                  `protobuf:"varint,2,opt,name=fail,proto3" json:"fail,omitempty"`
	Deviation     int64                  `protobuf:"varint,3,opt,name=deviation,proto3" json:"deviation,omitempty"`
	Average       int64                  `protobuf:"varint,4,opt,name=average,proto3" json:"average,omitempty"`
	Max           int64                  `protobuf:"varint,5,opt,name=max,proto3" json:"max,omitempty"`
	Min           int64                  `protobuf:"varint,6,opt,name=min,proto3" json:"min,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *HealthPingMeasurementResult) Reset() {
	*x = HealthPingMeasurementResult{}
	mi := &file_app_observatory_config_proto_msgTypes[1]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *HealthPingMeasurementResult) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*HealthPingMeasurementResult) ProtoMessage() {}

func (x *HealthPingMeasurementResult) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_config_proto_msgTypes[1]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use HealthPingMeasurementResult.ProtoReflect.Descriptor instead.
func (*HealthPingMeasurementResult) Descriptor() ([]byte, []int) {
	return file_app_observatory_config_proto_rawDescGZIP(), []int{1}
}

func (x *HealthPingMeasurementResult) GetAll() int64 {
	if x != nil {
		return x.All
	}
	return 0
}

func (x *HealthPingMeasurementResult) GetFail() int64 {
	if x != nil {
		return x.Fail
	}
	return 0
}

func (x *HealthPingMeasurementResult) GetDeviation() int64 {
	if x != nil {
		return x.Deviation
	}
	return 0
}

func (x *HealthPingMeasurementResult) GetAverage() int64 {
	if x != nil {
		return x.Average
	}
	return 0
}

func (x *HealthPingMeasurementResult) GetMax() int64 {
	if x != nil {
		return x.Max
	}
	return 0
}

func (x *HealthPingMeasurementResult) GetMin() int64 {
	if x != nil {
		return x.Min
	}
	return 0
}

type OutboundStatus struct {
	state protoimpl.MessageState `protogen:"open.v1"`
	// @Document Whether this outbound is usable
	// @Restriction ReadOnlyForUser
	Alive bool `protobuf:"varint,1,opt,name=alive,proto3" json:"alive,omitempty"`
	// @Document The time for probe request to finish.
	// @Type time.ms
	// @Restriction ReadOnlyForUser
	Delay int64 `protobuf:"varint,2,opt,name=delay,proto3" json:"delay,omitempty"`
	// @Document The last error caused this outbound failed to relay probe request
	// @Restriction NotMachineReadable
	LastErrorReason string `protobuf:"bytes,3,opt,name=last_error_reason,json=lastErrorReason,proto3" json:"last_error_reason,omitempty"`
	// @Document The outbound tag for this Server
	// @Type id.outboundTag
	OutboundTag string `protobuf:"bytes,4,opt,name=outbound_tag,json=outboundTag,proto3" json:"outbound_tag,omitempty"`
	// @Document The time this outbound is known to be alive
	// @Type id.outboundTag
	LastSeenTime int64 `protobuf:"varint,5,opt,name=last_seen_time,json=lastSeenTime,proto3" json:"last_seen_time,omitempty"`
	// @Document The time this outbound is tried
	// @Type id.outboundTag
	LastTryTime   int64                        `protobuf:"varint,6,opt,name=last_try_time,json=lastTryTime,proto3" json:"last_try_time,omitempty"`
	HealthPing    *HealthPingMeasurementResult `protobuf:"bytes,7,opt,name=health_ping,json=healthPing,proto3" json:"health_ping,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *OutboundStatus) Reset() {
	*x = OutboundStatus{}
	mi := &file_app_observatory_config_proto_msgTypes[2]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *OutboundStatus) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*OutboundStatus) ProtoMessage() {}

func (x *OutboundStatus) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_config_proto_msgTypes[2]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use OutboundStatus.ProtoReflect.Descriptor instead.
func (*OutboundStatus) Descriptor() ([]byte, []int) {
	return file_app_observatory_config_proto_rawDescGZIP(), []int{2}
}

func (x *OutboundStatus) GetAlive() bool {
	if x != nil {
		return x.Alive
	}
	return false
}

func (x *OutboundStatus) GetDelay() int64 {
	if x != nil {
		return x.Delay
	}
	return 0
}

func (x *OutboundStatus) GetLastErrorReason() string {
	if x != nil {
		return x.LastErrorReason
	}
	return ""
}

func (x *OutboundStatus) GetOutboundTag() string {
	if x != nil {
		return x.OutboundTag
	}
	return ""
}

func (x *OutboundStatus) GetLastSeenTime() int64 {
	if x != nil {
		return x.LastSeenTime
	}
	return 0
}

func (x *OutboundStatus) GetLastTryTime() int64 {
	if x != nil {
		return x.LastTryTime
	}
	return 0
}

func (x *OutboundStatus) GetHealthPing() *HealthPingMeasurementResult {
	if x != nil {
		return x.HealthPing
	}
	return nil
}

type ProbeResult struct {
	state protoimpl.MessageState `protogen:"open.v1"`
	// @Document Whether this outbound is usable
	// @Restriction ReadOnlyForUser
	Alive bool `protobuf:"varint,1,opt,name=alive,proto3" json:"alive,omitempty"`
	// @Document The time for probe request to finish.
	// @Type time.ms
	// @Restriction ReadOnlyForUser
	Delay int64 `protobuf:"varint,2,opt,name=delay,proto3" json:"delay,omitempty"`
	// @Document The error caused this outbound failed to relay probe request
	// @Restriction NotMachineReadable
	LastErrorReason string `protobuf:"bytes,3,opt,name=last_error_reason,json=lastErrorReason,proto3" json:"last_error_reason,omitempty"`
	unknownFields   protoimpl.UnknownFields
	sizeCache       protoimpl.SizeCache
}

func (x *ProbeResult) Reset() {
	*x = ProbeResult{}
	mi := &file_app_observatory_config_proto_msgTypes[3]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *ProbeResult) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*ProbeResult) ProtoMessage() {}

func (x *ProbeResult) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_config_proto_msgTypes[3]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use ProbeResult.ProtoReflect.Descriptor instead.
func (*ProbeResult) Descriptor() ([]byte, []int) {
	return file_app_observatory_config_proto_rawDescGZIP(), []int{3}
}

func (x *ProbeResult) GetAlive() bool {
	if x != nil {
		return x.Alive
	}
	return false
}

func (x *ProbeResult) GetDelay() int64 {
	if x != nil {
		return x.Delay
	}
	return 0
}

func (x *ProbeResult) GetLastErrorReason() string {
	if x != nil {
		return x.LastErrorReason
	}
	return ""
}

type Intensity struct {
	state protoimpl.MessageState `protogen:"open.v1"`
	// @Document The time interval for a probe request in ms.
	// @Type time.ms
	ProbeInterval uint32 `protobuf:"varint,1,opt,name=probe_interval,json=probeInterval,proto3" json:"probe_interval,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *Intensity) Reset() {
	*x = Intensity{}
	mi := &file_app_observatory_config_proto_msgTypes[4]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *Intensity) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*Intensity) ProtoMessage() {}

func (x *Intensity) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_config_proto_msgTypes[4]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use Intensity.ProtoReflect.Descriptor instead.
func (*Intensity) Descriptor() ([]byte, []int) {
	return file_app_observatory_config_proto_rawDescGZIP(), []int{4}
}

func (x *Intensity) GetProbeInterval() uint32 {
	if x != nil {
		return x.ProbeInterval
	}
	return 0
}

type Config struct {
	state protoimpl.MessageState `protogen:"open.v1"`
	// @Document The selectors for outbound under observation
	SubjectSelector       []string `protobuf:"bytes,2,rep,name=subject_selector,json=subjectSelector,proto3" json:"subject_selector,omitempty"`
	ProbeUrl              string   `protobuf:"bytes,3,opt,name=probe_url,json=probeUrl,proto3" json:"probe_url,omitempty"`
	ProbeInterval         int64    `protobuf:"varint,4,opt,name=probe_interval,json=probeInterval,proto3" json:"probe_interval,omitempty"`
	PersistentProbeResult bool     `protobuf:"varint,5,opt,name=persistent_probe_result,json=persistentProbeResult,proto3" json:"persistent_probe_result,omitempty"`
	unknownFields         protoimpl.UnknownFields
	sizeCache             protoimpl.SizeCache
}

func (x *Config) Reset() {
	*x = Config{}
	mi := &file_app_observatory_config_proto_msgTypes[5]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *Config) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*Config) ProtoMessage() {}

func (x *Config) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_config_proto_msgTypes[5]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use Config.ProtoReflect.Descriptor instead.
func (*Config) Descriptor() ([]byte, []int) {
	return file_app_observatory_config_proto_rawDescGZIP(), []int{5}
}

func (x *Config) GetSubjectSelector() []string {
	if x != nil {
		return x.SubjectSelector
	}
	return nil
}

func (x *Config) GetProbeUrl() string {
	if x != nil {
		return x.ProbeUrl
	}
	return ""
}

func (x *Config) GetProbeInterval() int64 {
	if x != nil {
		return x.ProbeInterval
	}
	return 0
}

func (x *Config) GetPersistentProbeResult() bool {
	if x != nil {
		return x.PersistentProbeResult
	}
	return false
}

var File_app_observatory_config_proto protoreflect.FileDescriptor

const file_app_observatory_config_proto_rawDesc = "" +
	"\n" +
	"\x1capp/observatory/config.proto\x12\x1av2ray.core.app.observatory\x1a common/protoext/extensions.proto\"W\n" +
	"\x11ObservationResult\x12B\n" +
	"\x06status\x18\x01 \x03(\v2*.v2ray.core.app.observatory.OutboundStatusR\x06status\"\x9f\x01\n" +
	"\x1bHealthPingMeasurementResult\x12\x10\n" +
	"\x03all\x18\x01 \x01(\x03R\x03all\x12\x12\n" +
	"\x04fail\x18\x02 \x01(\x03R\x04fail\x12\x1c\n" +
	"\tdeviation\x18\x03 \x01(\x03R\tdeviation\x12\x18\n" +
	"\aaverage\x18\x04 \x01(\x03R\aaverage\x12\x10\n" +
	"\x03max\x18\x05 \x01(\x03R\x03max\x12\x10\n" +
	"\x03min\x18\x06 \x01(\x03R\x03min\"\xaf\x02\n" +
	"\x0eOutboundStatus\x12\x14\n" +
	"\x05alive\x18\x01 \x01(\bR\x05alive\x12\x14\n" +
	"\x05delay\x18\x02 \x01(\x03R\x05delay\x12*\n" +
	"\x11last_error_reason\x18\x03 \x01(\tR\x0flastErrorReason\x12!\n" +
	"\foutbound_tag\x18\x04 \x01(\tR\voutboundTag\x12$\n" +
	"\x0elast_seen_time\x18\x05 \x01(\x03R\flastSeenTime\x12\"\n" +
	"\rlast_try_time\x18\x06 \x01(\x03R\vlastTryTime\x12X\n" +
	"\vhealth_ping\x18\a \x01(\v27.v2ray.core.app.observatory.HealthPingMeasurementResultR\n" +
	"healthPing\"e\n" +
	"\vProbeResult\x12\x14\n" +
	"\x05alive\x18\x01 \x01(\bR\x05alive\x12\x14\n" +
	"\x05delay\x18\x02 \x01(\x03R\x05delay\x12*\n" +
	"\x11last_error_reason\x18\x03 \x01(\tR\x0flastErrorReason\"2\n" +
	"\tIntensity\x12%\n" +
	"\x0eprobe_interval\x18\x01 \x01(\rR\rprobeInterval\"\xd5\x01\n" +
	"\x06Config\x12)\n" +
	"\x10subject_selector\x18\x02 \x03(\tR\x0fsubjectSelector\x12\x1b\n" +
	"\tprobe_url\x18\x03 \x01(\tR\bprobeUrl\x12%\n" +
	"\x0eprobe_interval\x18\x04 \x01(\x03R\rprobeInterval\x126\n" +
	"\x17persistent_probe_result\x18\x05 \x01(\bR\x15persistentProbeResult:$\x82\xb5\x18 \n" +
	"\aservice\x12\x15backgroundObservatoryBo\n" +
	"\x1ecom.v2ray.core.app.observatoryP\x01Z.github.com/v2fly/v2ray-core/v5/app/observatory\xaa\x02\x1aV2Ray.Core.App.Observatoryb\x06proto3"

var (
	file_app_observatory_config_proto_rawDescOnce sync.Once
	file_app_observatory_config_proto_rawDescData []byte
)

func file_app_observatory_config_proto_rawDescGZIP() []byte {
	file_app_observatory_config_proto_rawDescOnce.Do(func() {
		file_app_observatory_config_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_app_observatory_config_proto_rawDesc), len(file_app_observatory_config_proto_rawDesc)))
	})
	return file_app_observatory_config_proto_rawDescData
}

var file_app_observatory_config_proto_msgTypes = make([]protoimpl.MessageInfo, 6)
var file_app_observatory_config_proto_goTypes = []any{
	(*ObservationResult)(nil),           // 0: v2ray.core.app.observatory.ObservationResult
	(*HealthPingMeasurementResult)(nil), // 1: v2ray.core.app.observatory.HealthPingMeasurementResult
	(*OutboundStatus)(nil),              // 2: v2ray.core.app.observatory.OutboundStatus
	(*ProbeResult)(nil),                 // 3: v2ray.core.app.observatory.ProbeResult
	(*Intensity)(nil),                   // 4: v2ray.core.app.observatory.Intensity
	(*Config)(nil),                      // 5: v2ray.core.app.observatory.Config
}
var file_app_observatory_config_proto_depIdxs = []int32{
	2, // 0: v2ray.core.app.observatory.ObservationResult.status:type_name -> v2ray.core.app.observatory.OutboundStatus
	1, // 1: v2ray.core.app.observatory.OutboundStatus.health_ping:type_name -> v2ray.core.app.observatory.HealthPingMeasurementResult
	2, // [2:2] is the sub-list for method output_type
	2, // [2:2] is the sub-list for method input_type
	2, // [2:2] is the sub-list for extension type_name
	2, // [2:2] is the sub-list for extension extendee
	0, // [0:2] is the sub-list for field type_name
}

func init() { file_app_observatory_config_proto_init() }
func file_app_observatory_config_proto_init() {
	if File_app_observatory_config_proto != nil {
		return
	}
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_app_observatory_config_proto_rawDesc), len(file_app_observatory_config_proto_rawDesc)),
			NumEnums:      0,
			NumMessages:   6,
			NumExtensions: 0,
			NumServices:   0,
		},
		GoTypes:           file_app_observatory_config_proto_goTypes,
		DependencyIndexes: file_app_observatory_config_proto_depIdxs,
		MessageInfos:      file_app_observatory_config_proto_msgTypes,
	}.Build()
	File_app_observatory_config_proto = out.File
	file_app_observatory_config_proto_goTypes = nil
	file_app_observatory_config_proto_depIdxs = nil
}
