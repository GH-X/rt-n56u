package command

import (
	observatory "github.com/v2fly/v2ray-core/v5/app/observatory"
	_ "github.com/v2fly/v2ray-core/v5/common/protoext"
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

type GetOutboundStatusRequest struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	Tag           string                 `protobuf:"bytes,1,opt,name=Tag,proto3" json:"Tag,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *GetOutboundStatusRequest) Reset() {
	*x = GetOutboundStatusRequest{}
	mi := &file_app_observatory_command_command_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *GetOutboundStatusRequest) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*GetOutboundStatusRequest) ProtoMessage() {}

func (x *GetOutboundStatusRequest) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_command_command_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use GetOutboundStatusRequest.ProtoReflect.Descriptor instead.
func (*GetOutboundStatusRequest) Descriptor() ([]byte, []int) {
	return file_app_observatory_command_command_proto_rawDescGZIP(), []int{0}
}

func (x *GetOutboundStatusRequest) GetTag() string {
	if x != nil {
		return x.Tag
	}
	return ""
}

type GetOutboundStatusResponse struct {
	state         protoimpl.MessageState         `protogen:"open.v1"`
	Status        *observatory.ObservationResult `protobuf:"bytes,1,opt,name=status,proto3" json:"status,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *GetOutboundStatusResponse) Reset() {
	*x = GetOutboundStatusResponse{}
	mi := &file_app_observatory_command_command_proto_msgTypes[1]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *GetOutboundStatusResponse) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*GetOutboundStatusResponse) ProtoMessage() {}

func (x *GetOutboundStatusResponse) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_command_command_proto_msgTypes[1]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use GetOutboundStatusResponse.ProtoReflect.Descriptor instead.
func (*GetOutboundStatusResponse) Descriptor() ([]byte, []int) {
	return file_app_observatory_command_command_proto_rawDescGZIP(), []int{1}
}

func (x *GetOutboundStatusResponse) GetStatus() *observatory.ObservationResult {
	if x != nil {
		return x.Status
	}
	return nil
}

type Config struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *Config) Reset() {
	*x = Config{}
	mi := &file_app_observatory_command_command_proto_msgTypes[2]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *Config) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*Config) ProtoMessage() {}

func (x *Config) ProtoReflect() protoreflect.Message {
	mi := &file_app_observatory_command_command_proto_msgTypes[2]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use Config.ProtoReflect.Descriptor instead.
func (*Config) Descriptor() ([]byte, []int) {
	return file_app_observatory_command_command_proto_rawDescGZIP(), []int{2}
}

var File_app_observatory_command_command_proto protoreflect.FileDescriptor

const file_app_observatory_command_command_proto_rawDesc = "" +
	"\n" +
	"%app/observatory/command/command.proto\x12\"v2ray.core.app.observatory.command\x1a common/protoext/extensions.proto\x1a\x1capp/observatory/config.proto\",\n" +
	"\x18GetOutboundStatusRequest\x12\x10\n" +
	"\x03Tag\x18\x01 \x01(\tR\x03Tag\"b\n" +
	"\x19GetOutboundStatusResponse\x12E\n" +
	"\x06status\x18\x01 \x01(\v2-.v2ray.core.app.observatory.ObservationResultR\x06status\"(\n" +
	"\x06Config:\x1e\x82\xb5\x18\x1a\n" +
	"\vgrpcservice\x12\vobservatory2\xa9\x01\n" +
	"\x12ObservatoryService\x12\x92\x01\n" +
	"\x11GetOutboundStatus\x12<.v2ray.core.app.observatory.command.GetOutboundStatusRequest\x1a=.v2ray.core.app.observatory.command.GetOutboundStatusResponse\"\x00B\x87\x01\n" +
	"&com.v2ray.core.app.observatory.commandP\x01Z6github.com/v2fly/v2ray-core/v5/app/observatory/command\xaa\x02\"V2Ray.Core.App.Observatory.Commandb\x06proto3"

var (
	file_app_observatory_command_command_proto_rawDescOnce sync.Once
	file_app_observatory_command_command_proto_rawDescData []byte
)

func file_app_observatory_command_command_proto_rawDescGZIP() []byte {
	file_app_observatory_command_command_proto_rawDescOnce.Do(func() {
		file_app_observatory_command_command_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_app_observatory_command_command_proto_rawDesc), len(file_app_observatory_command_command_proto_rawDesc)))
	})
	return file_app_observatory_command_command_proto_rawDescData
}

var file_app_observatory_command_command_proto_msgTypes = make([]protoimpl.MessageInfo, 3)
var file_app_observatory_command_command_proto_goTypes = []any{
	(*GetOutboundStatusRequest)(nil),      // 0: v2ray.core.app.observatory.command.GetOutboundStatusRequest
	(*GetOutboundStatusResponse)(nil),     // 1: v2ray.core.app.observatory.command.GetOutboundStatusResponse
	(*Config)(nil),                        // 2: v2ray.core.app.observatory.command.Config
	(*observatory.ObservationResult)(nil), // 3: v2ray.core.app.observatory.ObservationResult
}
var file_app_observatory_command_command_proto_depIdxs = []int32{
	3, // 0: v2ray.core.app.observatory.command.GetOutboundStatusResponse.status:type_name -> v2ray.core.app.observatory.ObservationResult
	0, // 1: v2ray.core.app.observatory.command.ObservatoryService.GetOutboundStatus:input_type -> v2ray.core.app.observatory.command.GetOutboundStatusRequest
	1, // 2: v2ray.core.app.observatory.command.ObservatoryService.GetOutboundStatus:output_type -> v2ray.core.app.observatory.command.GetOutboundStatusResponse
	2, // [2:3] is the sub-list for method output_type
	1, // [1:2] is the sub-list for method input_type
	1, // [1:1] is the sub-list for extension type_name
	1, // [1:1] is the sub-list for extension extendee
	0, // [0:1] is the sub-list for field type_name
}

func init() { file_app_observatory_command_command_proto_init() }
func file_app_observatory_command_command_proto_init() {
	if File_app_observatory_command_command_proto != nil {
		return
	}
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_app_observatory_command_command_proto_rawDesc), len(file_app_observatory_command_command_proto_rawDesc)),
			NumEnums:      0,
			NumMessages:   3,
			NumExtensions: 0,
			NumServices:   1,
		},
		GoTypes:           file_app_observatory_command_command_proto_goTypes,
		DependencyIndexes: file_app_observatory_command_command_proto_depIdxs,
		MessageInfos:      file_app_observatory_command_command_proto_msgTypes,
	}.Build()
	File_app_observatory_command_command_proto = out.File
	file_app_observatory_command_command_proto_goTypes = nil
	file_app_observatory_command_command_proto_depIdxs = nil
}
