package stats

import (
	_ "github.com/v2fly/v2ray-core/v5/common/protoext"
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

type Config struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *Config) Reset() {
	*x = Config{}
	mi := &file_app_stats_config_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *Config) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*Config) ProtoMessage() {}

func (x *Config) ProtoReflect() protoreflect.Message {
	mi := &file_app_stats_config_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use Config.ProtoReflect.Descriptor instead.
func (*Config) Descriptor() ([]byte, []int) {
	return file_app_stats_config_proto_rawDescGZIP(), []int{0}
}

type ChannelConfig struct {
	state           protoimpl.MessageState `protogen:"open.v1"`
	Blocking        bool                   `protobuf:"varint,1,opt,name=Blocking,proto3" json:"Blocking,omitempty"`
	SubscriberLimit int32                  `protobuf:"varint,2,opt,name=SubscriberLimit,proto3" json:"SubscriberLimit,omitempty"`
	BufferSize      int32                  `protobuf:"varint,3,opt,name=BufferSize,proto3" json:"BufferSize,omitempty"`
	unknownFields   protoimpl.UnknownFields
	sizeCache       protoimpl.SizeCache
}

func (x *ChannelConfig) Reset() {
	*x = ChannelConfig{}
	mi := &file_app_stats_config_proto_msgTypes[1]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *ChannelConfig) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*ChannelConfig) ProtoMessage() {}

func (x *ChannelConfig) ProtoReflect() protoreflect.Message {
	mi := &file_app_stats_config_proto_msgTypes[1]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use ChannelConfig.ProtoReflect.Descriptor instead.
func (*ChannelConfig) Descriptor() ([]byte, []int) {
	return file_app_stats_config_proto_rawDescGZIP(), []int{1}
}

func (x *ChannelConfig) GetBlocking() bool {
	if x != nil {
		return x.Blocking
	}
	return false
}

func (x *ChannelConfig) GetSubscriberLimit() int32 {
	if x != nil {
		return x.SubscriberLimit
	}
	return 0
}

func (x *ChannelConfig) GetBufferSize() int32 {
	if x != nil {
		return x.BufferSize
	}
	return 0
}

var File_app_stats_config_proto protoreflect.FileDescriptor

const file_app_stats_config_proto_rawDesc = "" +
	"\n" +
	"\x16app/stats/config.proto\x12\x14v2ray.core.app.stats\x1a common/protoext/extensions.proto\"\x1e\n" +
	"\x06Config:\x14\x82\xb5\x18\x10\n" +
	"\aservice\x12\x05stats\"u\n" +
	"\rChannelConfig\x12\x1a\n" +
	"\bBlocking\x18\x01 \x01(\bR\bBlocking\x12(\n" +
	"\x0fSubscriberLimit\x18\x02 \x01(\x05R\x0fSubscriberLimit\x12\x1e\n" +
	"\n" +
	"BufferSize\x18\x03 \x01(\x05R\n" +
	"BufferSizeB]\n" +
	"\x18com.v2ray.core.app.statsP\x01Z(github.com/v2fly/v2ray-core/v5/app/stats\xaa\x02\x14V2Ray.Core.App.Statsb\x06proto3"

var (
	file_app_stats_config_proto_rawDescOnce sync.Once
	file_app_stats_config_proto_rawDescData []byte
)

func file_app_stats_config_proto_rawDescGZIP() []byte {
	file_app_stats_config_proto_rawDescOnce.Do(func() {
		file_app_stats_config_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_app_stats_config_proto_rawDesc), len(file_app_stats_config_proto_rawDesc)))
	})
	return file_app_stats_config_proto_rawDescData
}

var file_app_stats_config_proto_msgTypes = make([]protoimpl.MessageInfo, 2)
var file_app_stats_config_proto_goTypes = []any{
	(*Config)(nil),        // 0: v2ray.core.app.stats.Config
	(*ChannelConfig)(nil), // 1: v2ray.core.app.stats.ChannelConfig
}
var file_app_stats_config_proto_depIdxs = []int32{
	0, // [0:0] is the sub-list for method output_type
	0, // [0:0] is the sub-list for method input_type
	0, // [0:0] is the sub-list for extension type_name
	0, // [0:0] is the sub-list for extension extendee
	0, // [0:0] is the sub-list for field type_name
}

func init() { file_app_stats_config_proto_init() }
func file_app_stats_config_proto_init() {
	if File_app_stats_config_proto != nil {
		return
	}
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_app_stats_config_proto_rawDesc), len(file_app_stats_config_proto_rawDesc)),
			NumEnums:      0,
			NumMessages:   2,
			NumExtensions: 0,
			NumServices:   0,
		},
		GoTypes:           file_app_stats_config_proto_goTypes,
		DependencyIndexes: file_app_stats_config_proto_depIdxs,
		MessageInfos:      file_app_stats_config_proto_msgTypes,
	}.Build()
	File_app_stats_config_proto = out.File
	file_app_stats_config_proto_goTypes = nil
	file_app_stats_config_proto_depIdxs = nil
}
