package net

import (
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

// Address of a network host. It may be either an IP address or a domain
// address.
type IPOrDomain struct {
	state protoimpl.MessageState `protogen:"open.v1"`
	// Types that are valid to be assigned to Address:
	//
	//	*IPOrDomain_Ip
	//	*IPOrDomain_Domain
	Address       isIPOrDomain_Address `protobuf_oneof:"address"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *IPOrDomain) Reset() {
	*x = IPOrDomain{}
	mi := &file_common_net_address_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *IPOrDomain) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*IPOrDomain) ProtoMessage() {}

func (x *IPOrDomain) ProtoReflect() protoreflect.Message {
	mi := &file_common_net_address_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use IPOrDomain.ProtoReflect.Descriptor instead.
func (*IPOrDomain) Descriptor() ([]byte, []int) {
	return file_common_net_address_proto_rawDescGZIP(), []int{0}
}

func (x *IPOrDomain) GetAddress() isIPOrDomain_Address {
	if x != nil {
		return x.Address
	}
	return nil
}

func (x *IPOrDomain) GetIp() []byte {
	if x != nil {
		if x, ok := x.Address.(*IPOrDomain_Ip); ok {
			return x.Ip
		}
	}
	return nil
}

func (x *IPOrDomain) GetDomain() string {
	if x != nil {
		if x, ok := x.Address.(*IPOrDomain_Domain); ok {
			return x.Domain
		}
	}
	return ""
}

type isIPOrDomain_Address interface {
	isIPOrDomain_Address()
}

type IPOrDomain_Ip struct {
	// IP address. Must by either 4 or 16 bytes.
	Ip []byte `protobuf:"bytes,1,opt,name=ip,proto3,oneof"`
}

type IPOrDomain_Domain struct {
	// Domain address.
	Domain string `protobuf:"bytes,2,opt,name=domain,proto3,oneof"`
}

func (*IPOrDomain_Ip) isIPOrDomain_Address() {}

func (*IPOrDomain_Domain) isIPOrDomain_Address() {}

var File_common_net_address_proto protoreflect.FileDescriptor

const file_common_net_address_proto_rawDesc = "" +
	"\n" +
	"\x18common/net/address.proto\x12\x15v2ray.core.common.net\"C\n" +
	"\n" +
	"IPOrDomain\x12\x10\n" +
	"\x02ip\x18\x01 \x01(\fH\x00R\x02ip\x12\x18\n" +
	"\x06domain\x18\x02 \x01(\tH\x00R\x06domainB\t\n" +
	"\aaddressB`\n" +
	"\x19com.v2ray.core.common.netP\x01Z)github.com/v2fly/v2ray-core/v5/common/net\xaa\x02\x15V2Ray.Core.Common.Netb\x06proto3"

var (
	file_common_net_address_proto_rawDescOnce sync.Once
	file_common_net_address_proto_rawDescData []byte
)

func file_common_net_address_proto_rawDescGZIP() []byte {
	file_common_net_address_proto_rawDescOnce.Do(func() {
		file_common_net_address_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_common_net_address_proto_rawDesc), len(file_common_net_address_proto_rawDesc)))
	})
	return file_common_net_address_proto_rawDescData
}

var file_common_net_address_proto_msgTypes = make([]protoimpl.MessageInfo, 1)
var file_common_net_address_proto_goTypes = []any{
	(*IPOrDomain)(nil), // 0: v2ray.core.common.net.IPOrDomain
}
var file_common_net_address_proto_depIdxs = []int32{
	0, // [0:0] is the sub-list for method output_type
	0, // [0:0] is the sub-list for method input_type
	0, // [0:0] is the sub-list for extension type_name
	0, // [0:0] is the sub-list for extension extendee
	0, // [0:0] is the sub-list for field type_name
}

func init() { file_common_net_address_proto_init() }
func file_common_net_address_proto_init() {
	if File_common_net_address_proto != nil {
		return
	}
	file_common_net_address_proto_msgTypes[0].OneofWrappers = []any{
		(*IPOrDomain_Ip)(nil),
		(*IPOrDomain_Domain)(nil),
	}
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_common_net_address_proto_rawDesc), len(file_common_net_address_proto_rawDesc)),
			NumEnums:      0,
			NumMessages:   1,
			NumExtensions: 0,
			NumServices:   0,
		},
		GoTypes:           file_common_net_address_proto_goTypes,
		DependencyIndexes: file_common_net_address_proto_depIdxs,
		MessageInfos:      file_common_net_address_proto_msgTypes,
	}.Build()
	File_common_net_address_proto = out.File
	file_common_net_address_proto_goTypes = nil
	file_common_net_address_proto_depIdxs = nil
}
