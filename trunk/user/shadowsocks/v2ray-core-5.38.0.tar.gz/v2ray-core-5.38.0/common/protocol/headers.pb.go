package protocol

import (
	protoreflect "google.golang.org/protobuf/reflect/protoreflect"
	protoimpl "google.golang.org/protobuf/runtime/protoimpl"
	reflect "reflect"
	sync "sync"
	unsafe "unsafe"
)

const (
	// Verify that this generated code is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(20 - protoimpl.MinVersion)
	// Verify that runtime/protoimpl is sufficiently up-to-date.
	_ = protoimpl.EnforceVersion(protoimpl.MaxVersion - 20)
)

type SecurityType int32

const (
	SecurityType_UNKNOWN           SecurityType = 0
	SecurityType_LEGACY            SecurityType = 1
	SecurityType_AUTO              SecurityType = 2
	SecurityType_AES128_GCM        SecurityType = 3
	SecurityType_CHACHA20_POLY1305 SecurityType = 4
	SecurityType_NONE              SecurityType = 5
	SecurityType_ZERO              SecurityType = 6
)

// Enum value maps for SecurityType.
var (
	SecurityType_name = map[int32]string{
		0: "UNKNOWN",
		1: "LEGACY",
		2: "AUTO",
		3: "AES128_GCM",
		4: "CHACHA20_POLY1305",
		5: "NONE",
		6: "ZERO",
	}
	SecurityType_value = map[string]int32{
		"UNKNOWN":           0,
		"LEGACY":            1,
		"AUTO":              2,
		"AES128_GCM":        3,
		"CHACHA20_POLY1305": 4,
		"NONE":              5,
		"ZERO":              6,
	}
)

func (x SecurityType) Enum() *SecurityType {
	p := new(SecurityType)
	*p = x
	return p
}

func (x SecurityType) String() string {
	return protoimpl.X.EnumStringOf(x.Descriptor(), protoreflect.EnumNumber(x))
}

func (SecurityType) Descriptor() protoreflect.EnumDescriptor {
	return file_common_protocol_headers_proto_enumTypes[0].Descriptor()
}

func (SecurityType) Type() protoreflect.EnumType {
	return &file_common_protocol_headers_proto_enumTypes[0]
}

func (x SecurityType) Number() protoreflect.EnumNumber {
	return protoreflect.EnumNumber(x)
}

// Deprecated: Use SecurityType.Descriptor instead.
func (SecurityType) EnumDescriptor() ([]byte, []int) {
	return file_common_protocol_headers_proto_rawDescGZIP(), []int{0}
}

type SecurityConfig struct {
	state         protoimpl.MessageState `protogen:"open.v1"`
	Type          SecurityType           `protobuf:"varint,1,opt,name=type,proto3,enum=v2ray.core.common.protocol.SecurityType" json:"type,omitempty"`
	unknownFields protoimpl.UnknownFields
	sizeCache     protoimpl.SizeCache
}

func (x *SecurityConfig) Reset() {
	*x = SecurityConfig{}
	mi := &file_common_protocol_headers_proto_msgTypes[0]
	ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
	ms.StoreMessageInfo(mi)
}

func (x *SecurityConfig) String() string {
	return protoimpl.X.MessageStringOf(x)
}

func (*SecurityConfig) ProtoMessage() {}

func (x *SecurityConfig) ProtoReflect() protoreflect.Message {
	mi := &file_common_protocol_headers_proto_msgTypes[0]
	if x != nil {
		ms := protoimpl.X.MessageStateOf(protoimpl.Pointer(x))
		if ms.LoadMessageInfo() == nil {
			ms.StoreMessageInfo(mi)
		}
		return ms
	}
	return mi.MessageOf(x)
}

// Deprecated: Use SecurityConfig.ProtoReflect.Descriptor instead.
func (*SecurityConfig) Descriptor() ([]byte, []int) {
	return file_common_protocol_headers_proto_rawDescGZIP(), []int{0}
}

func (x *SecurityConfig) GetType() SecurityType {
	if x != nil {
		return x.Type
	}
	return SecurityType_UNKNOWN
}

var File_common_protocol_headers_proto protoreflect.FileDescriptor

const file_common_protocol_headers_proto_rawDesc = "" +
	"\n" +
	"\x1dcommon/protocol/headers.proto\x12\x1av2ray.core.common.protocol\"N\n" +
	"\x0eSecurityConfig\x12<\n" +
	"\x04type\x18\x01 \x01(\x0e2(.v2ray.core.common.protocol.SecurityTypeR\x04type*l\n" +
	"\fSecurityType\x12\v\n" +
	"\aUNKNOWN\x10\x00\x12\n" +
	"\n" +
	"\x06LEGACY\x10\x01\x12\b\n" +
	"\x04AUTO\x10\x02\x12\x0e\n" +
	"\n" +
	"AES128_GCM\x10\x03\x12\x15\n" +
	"\x11CHACHA20_POLY1305\x10\x04\x12\b\n" +
	"\x04NONE\x10\x05\x12\b\n" +
	"\x04ZERO\x10\x06Bo\n" +
	"\x1ecom.v2ray.core.common.protocolP\x01Z.github.com/v2fly/v2ray-core/v5/common/protocol\xaa\x02\x1aV2Ray.Core.Common.Protocolb\x06proto3"

var (
	file_common_protocol_headers_proto_rawDescOnce sync.Once
	file_common_protocol_headers_proto_rawDescData []byte
)

func file_common_protocol_headers_proto_rawDescGZIP() []byte {
	file_common_protocol_headers_proto_rawDescOnce.Do(func() {
		file_common_protocol_headers_proto_rawDescData = protoimpl.X.CompressGZIP(unsafe.Slice(unsafe.StringData(file_common_protocol_headers_proto_rawDesc), len(file_common_protocol_headers_proto_rawDesc)))
	})
	return file_common_protocol_headers_proto_rawDescData
}

var file_common_protocol_headers_proto_enumTypes = make([]protoimpl.EnumInfo, 1)
var file_common_protocol_headers_proto_msgTypes = make([]protoimpl.MessageInfo, 1)
var file_common_protocol_headers_proto_goTypes = []any{
	(SecurityType)(0),      // 0: v2ray.core.common.protocol.SecurityType
	(*SecurityConfig)(nil), // 1: v2ray.core.common.protocol.SecurityConfig
}
var file_common_protocol_headers_proto_depIdxs = []int32{
	0, // 0: v2ray.core.common.protocol.SecurityConfig.type:type_name -> v2ray.core.common.protocol.SecurityType
	1, // [1:1] is the sub-list for method output_type
	1, // [1:1] is the sub-list for method input_type
	1, // [1:1] is the sub-list for extension type_name
	1, // [1:1] is the sub-list for extension extendee
	0, // [0:1] is the sub-list for field type_name
}

func init() { file_common_protocol_headers_proto_init() }
func file_common_protocol_headers_proto_init() {
	if File_common_protocol_headers_proto != nil {
		return
	}
	type x struct{}
	out := protoimpl.TypeBuilder{
		File: protoimpl.DescBuilder{
			GoPackagePath: reflect.TypeOf(x{}).PkgPath(),
			RawDescriptor: unsafe.Slice(unsafe.StringData(file_common_protocol_headers_proto_rawDesc), len(file_common_protocol_headers_proto_rawDesc)),
			NumEnums:      1,
			NumMessages:   1,
			NumExtensions: 0,
			NumServices:   0,
		},
		GoTypes:           file_common_protocol_headers_proto_goTypes,
		DependencyIndexes: file_common_protocol_headers_proto_depIdxs,
		EnumInfos:         file_common_protocol_headers_proto_enumTypes,
		MessageInfos:      file_common_protocol_headers_proto_msgTypes,
	}.Build()
	File_common_protocol_headers_proto = out.File
	file_common_protocol_headers_proto_goTypes = nil
	file_common_protocol_headers_proto_depIdxs = nil
}
