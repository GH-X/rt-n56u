package main

import "github.com/apernet/hysteria/app/v2/cmd"

func main() {
	cmd.Execute()
}
